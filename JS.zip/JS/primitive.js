/* to define variable use let */
let name='Harry Potter';
let age='1'; /* here on console part when you type typeof age
you get string thats because you have given value in string so */
let option=true;
let height; /* you get undefined cause defined wihout initialising 
not initialising causing undefined */
let eyecolour=null; /* null for explicitly clear value of variable */
console.log(age);
console.log(name); 
console.log(option);
console.log(height);
console.log(eyecolour);