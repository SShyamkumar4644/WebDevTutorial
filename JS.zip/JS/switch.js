let games="football";
switch(games) {
    case "throwball":
        console.log("I hate thrwoball");
        break;
    case "basketball":
        console.log("Basketball is hard");
        break;
    case "cricket":
        console.log("I'm a huge cricket fan");
        break;
    case "football":
        console.log("I love football"); // this executes
        break;
    default:
        console.log("I like other games");
        break;
}