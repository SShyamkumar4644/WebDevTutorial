let i=0;
/* while(i<5) {
    console.log("The number is " +i);
    i++;
}*/
// The number is 0
//The number is 1
//The number is 2
//The number is 3
//The number is 4

do{

    console.log("The number is " +i); //first execute these stmts incremets
    i++;
}
while(i>5); // and check condition, false then come out
// commeting out firts above while condition ptrints only 0

