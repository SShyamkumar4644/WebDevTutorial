for(let i=0;i<5;i++) { // declaring and initialising inside itself
    console.log("The number is " +i);
}
// first 0 is printed then it checks i<5 if true it
//executes after excution and third one excutes

for(i=0;i<50;i++) {
    console.log(i+ ".I'm sorry");

}