let pen={ //creating objects using curly brackets, like key value pairs

    type: 'ballpoint',
    color:'black',
    cost:10

};
//objectname.propertname for accessing an object
//another way by objectname['propertyname']
console.log(pen.cost); //10

let emily={

    age:16,
    school:'DPS',
    class:'10th std',
    subjects:['physics','chemistry','biology','maths']

};

console.log(emily.subjects[1]); //chemistry