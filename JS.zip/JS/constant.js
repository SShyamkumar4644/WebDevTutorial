const pi=3.14;
pi=3.12;
console.log(pi); /* You get constant.js:2 
        
Uncaught TypeError: Assignment to constant variable.
at constant.js:2:3 error on sonsole part of index.html inspect element page */